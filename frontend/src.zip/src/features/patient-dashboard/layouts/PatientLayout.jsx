import { Outlet, Link, useLocation } from 'react-router-dom';
import {
  CalendarIcon,
  ClipboardDocumentIcon,
  UserCircleIcon,
  HomeIcon,
  HeartIcon
} from '@heroicons/react/24/outline';

export default function PatientLayout() {
  const location = useLocation();
  
  const navItems = [
    { name: 'Dashboard', icon: HomeIcon, path: '/patient-dashboard' },
    { name: 'Appointments', icon: CalendarIcon, path: '/patient-dashboard/appointments' },
    { name: 'Prescriptions', icon: ClipboardDocumentIcon, path: '/patient-dashboard/prescriptions' },
    { name: 'Medical Records', icon: HeartIcon, path: '/patient-dashboard/records' },
    { name: 'Profile', icon: UserCircleIcon, path: '/patient-dashboard/profile' }
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-md">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-blue-800">Patient Portal</h2>
        </div>
        <nav className="p-4 space-y-2">
          {navItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`flex items-center p-3 rounded-lg transition-colors ${
                location.pathname === item.path
                  ? 'bg-blue-100 text-blue-700'
                  : 'hover:bg-gray-100 text-gray-700'
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.name}
            </Link>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        <Outlet />
      </div>
    </div>
  );
}