package com.example.healthcare.entity.enums;

public enum NotificationType
{
    APPOINTMENT,
    PRESCRIPTION,
    MESSAGE,
    ADMIN_ALERT,
    GENERAL
}
